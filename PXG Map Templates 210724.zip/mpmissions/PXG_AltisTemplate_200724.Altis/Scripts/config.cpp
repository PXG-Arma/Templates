class CfgFunctions
{   
    #include <Respawn\cfgFunctions.hpp>
    #include <Markers\cfgFunctions.hpp>
};

class CfgRemoteExec
{
    #include <cfgRemoteExec.hpp>
};

#include <cfgExtendedEventHandlers.hpp>

#include <macros.hpp>

#include <Respawn\config.cpp>
#include <Markers\config.cpp>

