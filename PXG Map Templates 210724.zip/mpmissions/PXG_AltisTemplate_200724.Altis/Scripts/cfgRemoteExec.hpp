class functions{
	mode = 2; 
	jip = 1; 
};