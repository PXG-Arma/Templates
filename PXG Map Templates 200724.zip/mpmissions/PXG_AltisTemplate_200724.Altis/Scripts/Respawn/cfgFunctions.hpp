class pxg_Respawn{
	class functions{
		file = "Scripts\respawn\functions";

		class zeusSetup{};
		class addActionMenu{};
		class removeActionMenu{};

		class addRespawnWave{};
		class respawnPlayers{};
		class setRespawnTime{};
		class startRespawnWave{};
		
		class respawnOnePLayer{};
		class respawnOnePLayerRemote{};
	};

	class gui_functions{
		file = "Scripts\respawn\dialogs";

		class openDialog{};
	};

	class xeh{
		file = "Scripts\respawn\xeh";

		class preInit{};
		class postInit{};
	};
};